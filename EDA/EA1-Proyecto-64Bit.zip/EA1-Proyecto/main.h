#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>

#include "funciones.h"


void probarCadenas();

void probarMatrices();

void probarArchivosYPila();


#endif // MAIN_H_

