/**//* 22.333.444-PEREZ_DEL_RIO,JuanManuel-(07-2299) *//**/

#include "funciones.h"


/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//* FUNCIONES A DESARROLLAR                                            *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//**//* PUNTO 2                                            *//**//**//**/
/*
int  cargarCuadrMagico_MIO(int m[][TAM_MAT], int filas, int colum)
{

}
 */
/*
int mostrarMat_MIO(int m[][TAM_MAT], int filas, int colum, FILE *fp)
{

}
 */

/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

