/**//* 22.333.444-PEREZ_DEL_RIO,JuanManuel-(07-2299) *//**/


#include "funciones.h"



/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//* FUNCIONES A DESARROLLAR                                            *//**/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/
/**//**//**//* PUNTO 3                                            *//**//**//**/
/**/
/*

int  procesarPedidos_MIO(FILE *fpPedi, FILE *fpPend, FILE *fpMayo, FILE *fpMeno,
                         FILE *fpPant);

 */
/**//**//**//*  DESARROLLE LAS PRIMITIVAS DE PILA CON ASIGNACI�N  *//**//**//**/
/**//**//**//*  DIN�MICA DE MEMORIA COMO TIENE EST� EN LA BIBLIO- *//**//**//**/
/**//**//**//*  GRAF�A PROVISTA EN EL CURSO EN LA  [SEMANA 7]     *//**//**//**/
/*

void crearPila_MIO(tPila *p)
{

}


int  pilaLlena_MIO(const tPila *p, unsigned cantBytes)
{

}


int  ponerEnPila_MIO(tPila *p, const void *d, unsigned cantBytes)
{

}


int  verTope_MIO(const tPila *p, void *d, unsigned cantBytes)
{

}


int  pilaVacia_MIO(const tPila *p)
{

}


int  sacarDePila_MIO(tPila *p, void *d, unsigned cantBytes)
{

}


void vaciarPila_MIO(tPila *p)
{

}

*/
/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

